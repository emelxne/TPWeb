import styled from 'styled-components'

function App() {
  return (
    <Appli>
      je suis la 
    </Appli>
  );
}

export default App;

const Appli = styled.div`
  background-color: blue;
`